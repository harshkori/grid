# Magento 2 Rest API Development video series 

### #0 - Magento 2 PhpStorm Plugin Setup
YouTube video - https://youtu.be/eCbEEfYreFU  

### #1 - GET method endpoint example
YouTube video - https://youtu.be/7s3AOdOrH3M     
Source code - https://github.com/troublediehard/Magento-2-Rest-API-Development-Tutorial/tree/1-get-method-endpoint-example

### #2 - Rest API Access Levels (ACL)
YouTube video - https://youtu.be/9OpjTwifhaE     
Source code - https://github.com/troublediehard/Magento-2-Rest-API-Development-Tutorial/tree/2-Rest-API-Access-Levels

### #3 - Rest API Response Object example
YouTube video - https://youtu.be/8JU12BM8kpc     
Source code - https://github.com/troublediehard/Magento-2-Rest-API-Development-Tutorial/tree/3-rest-api-response-object
