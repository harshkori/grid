<?php

namespace Custom\Purchased\Model\ResourceModel;

class Purchased extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {       
        $this->_init('import_product', 'id');
    }
}