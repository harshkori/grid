<?php

namespace Custom\Purchased\Controller\Adminhtml\Index;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Filesystem;

class Index extends \Magento\Backend\App\Action
{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        ManagerInterface $messageManager,
        Filesystem $filesystem,
        ResourceConnection $resourceConnection,
        UploaderFactory $fileUploader,
        \Magento\Framework\Filesystem\DirectoryList $dir

    ) {
        parent::__construct($context);
        $this->resultPageFactory    =       $resultPageFactory;
        $this->resourceConnection   =       $resourceConnection;
        $this->messageManager       =       $messageManager;
        $this->filesystem           =       $filesystem;
        $this->fileUploader         =       $fileUploader;
        $this->mediaDirectory       =       $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);


    }
    /**
     * Check the permission to run it
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Custom_Purchased::custom_purchased');
    }

    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Custom_Purchased::custom_purchased');
        $resultPage->addBreadcrumb(__('Purchased'), __('Purchased'));
        $resultPage->addBreadcrumb(__('Purchased Orders'), __('Purchased Orders'));
        $resultPage->getConfig()->getTitle()->prepend(__('Product List'));

        $file = $this->getRequest()->getFiles('csvfiles');
        $fileName = ($file && array_key_exists('name', $file)) ? $file['name'] : null;
        $connection = $this->resourceConnection->getConnection();
        if ($file && $fileName)

        {
            echo "posted";
        }
        else
        {
            return $resultPage;

        }

    }
}
