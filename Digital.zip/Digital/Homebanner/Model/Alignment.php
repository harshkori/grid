<?php

namespace Digital\Homebanner\Model;

class Alignment
{
    /**#@+
     * Status values
     */

    const STATUS_CENTER = 1;

    const STATUS_RIGHT = 2;

    const STATUS_LEFT = 3;

    /**
     * Retrieve option array
     *
     * @return string[]
     */
    public static function getOptionArray()
    {
        return [self::STATUS_CENTER => __('Center'), self::STATUS_RIGHT => __('Right'), self::STATUS_LEFT => __('Left')];
    }


    /**
     * Retrieve option array with empty value
     *
     * @return string[]
     */
    public function getAllOptions()
    {
        $result = [];

        foreach (self::getOptionArray() as $index => $value) {
            $result[] = ['value' => $index, 'label' => $value];
        }

        return $result;
    }

    /**
     * Retrieve option text by option value
     *
     * @param string $optionId
     * @return string
     */
    public function getOptionText($optionId)
    {
        $options = self::getOptionArray();

        return isset($options[$optionId]) ? $options[$optionId] : null;
    }
}