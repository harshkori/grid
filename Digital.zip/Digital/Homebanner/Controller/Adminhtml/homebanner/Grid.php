<?php

namespace Digital\Homebanner\Controller\Adminhtml\Homebanner;

class Grid extends \Magento\Customer\Controller\Adminhtml\Index
{
    /**
     * Customer grid action
     *
     * @return void
     */
    protected function _isAllowed()
    {        
        return true;
    }
    
    public function execute()
    {
        $this->_view->loadLayout(false);
        $this->_view->renderLayout();
    }
}
