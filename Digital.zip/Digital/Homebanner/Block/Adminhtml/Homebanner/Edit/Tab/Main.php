<?php
namespace Digital\Homebanner\Block\Adminhtml\Homebanner\Edit\Tab;

/**
 * Homebanner edit form main tab
 */

class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */

    protected $_systemStore;
    /**
     * @var \Digital\Homebanner\Model\Status
     */
    protected $_status;
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Digital\Homebanner\Model\Status $status,
        \Digital\Homebanner\Model\Alignment $alignment,
        array $data = []

    ) {
        $this->_systemStore = $systemStore;
        $this->_status = $status;
        $this->_alignment = $alignment;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */

    protected function _prepareForm()
    {
        /* @var $model \Digital\Homebanner\Model\BlogPosts */
        $model = $this->_coreRegistry->registry('homebanner');
        $isElementDisabled = false;
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('page_');
        $htmlIdPrefix = $form->getHtmlIdPrefix();
        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Home Banner Information')]);
        if ($model->getId()) {
            $fieldset->addField('banner_id', 'hidden', ['name' => 'banner_id']);
        }

        $fieldset->addField(
            'name',
            'text',
            [
                'name' => 'name',
                'label' => __('Home Banner Name'),
                'title' => __('Home Banner Name'),
                'required' => true,
                'disabled' => $isElementDisabled,
            ]
        );

        $fieldset->addField(
            'banner_url',
            'text',
            [
                'name' => 'banner_url',
                'label' => __('Home Banner Url'),
                'title' => __('Home Banner Url'),
                'required' => false,
                'note' => 'Button will be displayed Only if link is not empty,<br/> For external linking please add link with "http", for internal linking simple add after Base URL link for example "example.html',
                'disabled' => $isElementDisabled,
            ]

        );

        /*$fieldset->addField(
            'banner_title',
            'text',
            [
                'name' => 'banner_title',
                'label' => __('Banner Title'),
                'title' => __('Banner Title'),
                'required' => false,
                'note' => 'Please add upto maximum 15 characters',
                'disabled' => $isElementDisabled,
            ]
        );

        $fieldset->addField(
            'sort_description',
            'textarea',
            [
                'name' => 'sort_description',
                'label' => __('Short Description'),
                'title' => __('Short Description'),
                'required' => false,
                'note' => 'Please add upto maximum 100 characters',
                'disabled' => $isElementDisabled,
            ]
        );
*/
        $fieldset->addField(
            'status',
            'select',
            [
                'label' => __('Banner Status'),
                'title' => __('Banner Status'),
                'name' => 'status',
                'required' => false,
                'options' => $this->_status->getOptionArray(),
                'disabled' => $isElementDisabled,
            ]

        );

        $fieldset->addField(
            'image',
            'image',
            [
                'name' => 'image',
                'label' => __('Desktop Image'),
                'title' => __('Desktop Image'),
                'required' => false,
                'disabled' => $isElementDisabled,
                'note' => 'Allowed image types: jpg, jpeg, png | <strong>Recommended Dimensions:</strong> W1920px * H500px',
            ]

        );

        $fieldset->addField(
            'mobile_image',
            'image',
            [
                'name' => 'mobile_image',
                'label' => __('Mobile Image'),
                'title' => __('Mobile Image'),
                'required' => false,
                'disabled' => $isElementDisabled,
                'note' => 'Allowed image types: jpg, jpeg, png | <strong>Recommended Dimensions:</strong> W950px * H950px',
            ]
        );

        $fieldset->addField(
            'tablet_image',
            'image',
            [
                'name' => 'tablet_image',
                'label' => __('Tablet Image'),
                'title' => __('Tablet Image'),
                'required' => false,
                'disabled' => $isElementDisabled,
                'note' => 'Allowed image types: jpg, jpeg, png | <strong>Recommended Dimensions:</strong> W1024px * H400px',
            ]

        );

 /*       $fieldset->addField(
            'button_text',
            'text',
            [
                'name' => 'button_text',
                'label' => __('Button Caption'),
                'title' => __('Button Caption'),
                'note' => 'This will be displayed as a Text on button and if leave it as empty then Button will simply be appeared with text "Discover More"<br/>Please add upto maximum 15 characters',
                'required' => false,
                'disabled' => $isElementDisabled,
            ]

        );

        $fieldset->addField(
            'content_align',
            'select',
            [
                'label' => __('Content Alignment'),
                'title' => __('Content Alignment'),
                'name' => 'content_align',
                'options' => $this->_alignment->getOptionArray(),
                'disabled' => $isElementDisabled,
            ]
        );*/

        if (!$this->_storeManager->isSingleStoreMode()) {
            $field = $fieldset->addField(
                'stores',
                'multiselect',
                [
                    'name' => 'stores[]',
                    'label' => __('Store View'),
                    'title' => __('Store View'),
                    'required' => true,
                    'values' => $this->_systemStore->getStoreValuesForForm(false, true),
                    'disabled' => $isElementDisabled,
                ]
            );

            $renderer = $this->getLayout()->createBlock('Magento\Backend\Block\Store\Switcher\Form\Renderer\Fieldset\Element');
            $field->setRenderer($renderer);
        } else {
            $fieldset->addField(
                'stores',
                'hidden',
                ['name' => 'stores[]', 'value' => $this->_storeManager->getStore(true)->getId()]
            );
            $model->setStores($this->_storeManager->getStore(true)->getId());
        }

        $fieldset->addField(
            'sort_order',
            'text',
            [
                'name' => 'sort_order',
                'label' => __('Sort Order'),
                'title' => __('Sort Order'),
                'disabled' => $isElementDisabled,
            ]

        );

        if (!$model->getId()) {
            $model->setData('is_active', $isElementDisabled ? '0' : '1');
        }

        $form->setValues($model->getData());
        $this->setForm($form);
        return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */

    public function getTabLabel()
    {
        return __('Home Banner Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */

    public function getTabTitle()
    {
        return __('Home Banner Information');
    }

    /**
     * {@inheritdoc}
     */

    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */

    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */

    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    public function getTargetOptionArray()
    {
        return array(
            '_self' => "Self",
            '_blank' => "New Page",
        );
    }
}
